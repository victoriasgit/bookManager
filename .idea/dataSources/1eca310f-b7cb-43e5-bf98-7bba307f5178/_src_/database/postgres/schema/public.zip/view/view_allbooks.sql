CREATE VIEW view_allbooks AS SELECT books.book_id,
    books.book_title,
    books.book_price,
    genres.genre_title,
    authors.author_surname,
    authors.author_name
   FROM ((books
     JOIN authors ON ((books.author_id = authors.author_id)))
     JOIN genres ON ((books.genre_id = genres.genre_id)));
